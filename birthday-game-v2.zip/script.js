const character = document.getElementById("character");
const bubble = document.getElementById("bubble");
const choicesDiv = document.getElementById("choices");

let currentScenes = [];
let sceneIndex = 0;
let typing = false;
let fullText = "";

function typeText(text, callback) {
  bubble.innerHTML = "";
  bubble.classList.remove("hidden");
  fullText = text;
  let i = 0;
  typing = true;

  function type() {
    if (i < text.length) {
      bubble.innerHTML += text[i];
      i++;
      setTimeout(type, 25);
    } else {
      typing = false;
      if (callback) callback();
    }
  }
  type();
}

function completeText() {
  bubble.innerHTML = fullText;
  typing = false;
}

function loadScene(scene) {
  character.style.opacity = 0;
  setTimeout(() => {
    character.src = scene.img || "";
    character.style.opacity = 1;

    if (scene.text) {
      typeText(scene.text, () => {
        if (scene.choices) showChoices(scene.choices);
      });
    } else {
      bubble.classList.add("hidden");
      if (scene.choices) showChoices(scene.choices);
    }
  }, 200);
}

function nextScene() {
  if (typing) {
    completeText();
    return;
  }
  if (sceneIndex < currentScenes.length) {
    loadScene(currentScenes[sceneIndex]);
    sceneIndex++;
  }
}

function showChoices(options) {
  choicesDiv.innerHTML = "";
  choicesDiv.classList.remove("hidden");

  options.forEach(opt => {
    let btn = document.createElement("button");
    btn.innerText = opt.text;
    btn.onclick = () => {
      choicesDiv.classList.add("hidden");
      startPath(opt.next);
    };
    choicesDiv.appendChild(btn);
  });
}

function startPath(pathName) {
  currentScenes = paths[pathName];
  sceneIndex = 0;
}

const mainStory = [
  { img: "images/bg_park.png", text: "" },
  { img: "images/gojo_peek.png", text: "👀" },
  { img: "images/gojo_twerk.gif", text: "" },
  { img: "images/gojo_hi.png", text: "Hi." },
  { img: "images/anywhere_girl.png", text: "..." },
  { img: "images/gojo_emotional.png", text: "Do you know how long I waited for this day..." },
  { img: "images/anywhere_girl.png", text: "???" },
  { img: "images/gojo_emotional.png", text: "It's your birthday." },
  { img: "images/gojo_cake.png", text: "Here... take this 🎂" },
  { img: "images/girl_blow_candle.png", text: "" },
  { img: "images/gojo_eat_cake.png", text: "" },
  { img: "images/anywhere_girl.png", text: "..." },
  { img: "images/gojo_gift.png", text: "I brought you a gift." },
  { img: "images/gojo_girl.png", text: "" },
  {
    img: "images/girl_angry.png",
    text: "...",
    choices: [
      { text: "Slap him", next: "slapPath" },
      { text: "Laugh it off", next: "laughPath" }
    ]
  }
];

const paths = {
  laughPath: [
    { img: "images/gojo_hi.png", text: "Glad you liked it 😎" }
  ],
  slapPath: [
    { img: "images/slap.png", text: "*SLAP*" },
    {
      img: "images/gojo_cry.png",
      text: "😭😭😭",
      choices: [
        { text: "Comfort him", next: "comfortPath" },
        { text: "Leave", next: "leavePath" }
      ]
    }
  ],
  leavePath: [
    { img: "images/girl_back.png", text: "" },
    { img: "images/gojo_cry.png", text: "He cries louder." }
  ],
  comfortPath: [
    { img: "images/girl_comfort.png", text: "" },
    { img: "images/gojo_calm.png", text: "sniff..." },
    {
      img: "images/gojo_hug_attempt.png",
      text: "",
      choices: [
        { text: "Push him", next: "pushPath" },
        { text: "Hug him", next: "hugPath" }
      ]
    }
  ],
  pushPath: [
    { img: "images/push.png", text: "" },
    { img: "images/girl_back.png", text: "She leaves." }
  ],
  hugPath: [
    { img: "images/hug.png", text: "" },
    { img: "images/hand_kiss.png", text: "" },
    { img: "images/gojo_run.png", text: "Gurl, you're fast but not fast enoughhh 😭" },
    { img: "images/girl_tired.png", text: "" }
  ]
};

currentScenes = mainStory;
sceneIndex = 0;

document.addEventListener("click", nextScene);
